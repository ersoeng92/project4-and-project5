import java.util.Collections;
import java.util.LinkedList;
import java.util.Scanner;

/**
 * This program reads integers from user input,
 * stores them in a LinkedList from the Java Collections Framework,
 * and sorts the list in ascending order.
 *
 * <p>Code reuse:
 * We reuse the built-in {@link java.util.LinkedList} and
 * {@link java.util.Collections#sort(java.util.List)} method to simplify implementation.
 * </p>
 */
public class SortedLinkedList {

    /**
     * Main entry point for the program.
     * Reads integers from standard input, stores them in a linked list,
     * sorts the list, and prints the sorted list.
     *
     * @param args command-line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        LinkedList<Integer> list = new LinkedList<>();

        System.out.println("Enter integers separated by space:");

        String inputLine = scanner.nextLine();
        String[] tokens = inputLine.trim().split("\\s+");

        for (String token : tokens) {
            try {
                int num = Integer.parseInt(token);
                list.add(num);  // Just add the number, no sorting yet
            } catch (NumberFormatException e) {
                System.out.println("Invalid input ignored: " + token);
            }
        }

        // Sort the linked list using Collections.sort()
        Collections.sort(list);

        System.out.println("Sorted LinkedList: " + list);
        scanner.close();
    }
}