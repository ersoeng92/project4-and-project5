import java.util.*;

/**
 * The SortedStack program demonstrates how to read integers from user input,
 * store them in a stack, sort them in ascending order, and push them back
 * onto a stack in such a way that popping the stack returns the integers
 * in ascending order, preserving LIFO behavior.
 *
 * <p>This version corrects the original implementation that used
 * {@link Collections#sort(List)} directly on the stack, which violates
 * stack semantics. Instead, it uses a temporary list to sort the values,
 * then pushes them in reverse order into the stack.</p>
 *
 * <p>Design Goal:
 * Preserve LIFO behavior while returning sorted values through standard
 * stack operations (push/pop).</p>
 *
 * @author You
 */
public class SortedStack {

    /**
     * Main method that reads integers from the user, sorts them,
     * and stores them in a stack so that popping the stack returns
     * values in ascending order.
     *
     * @param args Command-line arguments (not used)
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Stack<Integer> stack = new Stack<>();

        System.out.println("Enter integers separated by space:");
        String inputLine = scanner.nextLine();
        String[] tokens = inputLine.trim().split("\\s+");

        // Use a temporary list to store numbers for sorting
        List<Integer> tempList = new ArrayList<>();

        for (String token : tokens) {
            try {
                int num = Integer.parseInt(token);
                tempList.add(num);
            } catch (NumberFormatException e) {
                System.out.println("Invalid input ignored: " + token);
            }
        }

        // Sort the list in ascending order
        Collections.sort(tempList);

        // Push sorted elements in reverse order to maintain LIFO behavior
        for (int i = tempList.size() - 1; i >= 0; i--) {
            stack.push(tempList.get(i));
        }

        // Display stack as stored (top of stack is at the end of list view)
        System.out.println("Sorted Stack (Top to Bottom): " + stack);

        // Optional: Demonstrate popping to show ascending order
        System.out.print("Popping values (ascending): ");
        while (!stack.isEmpty()) {
            System.out.print(stack.pop() + " ");
        }

        scanner.close();
    }
}


